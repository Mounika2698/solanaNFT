const WrongNetwork = () => {
  return <div>Wrong Network!</div>;
};

export default WrongNetwork;
