import React from "react";
import { Layout, Row, Col } from "antd";
import { Content, Footer, Header } from "antd/lib/layout/layout";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button, Checkbox, Form, Input, Card, Divider, Typography } from "antd";
import "antd/dist/antd.css";
import { useNavigate } from "react-router-dom";
import logo from "../images/sol.png";


const Register = (props) => {
  const navigate = useNavigate()
  const { Title } = Typography;
  const onFinish = (values) => {
    console.log("Success:", values);
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  const handleRegister = () =>{
    navigate("/mint")
  }
  return (
    <>
      <Col span={24}>
        <Layout style={{ minHeight: "100vh" }}>
          <Header>
            <Row align="stretch" gutter={20} style={{color:"#fff"}}>
            <Col>
                <img src={logo} width={40} height={40} />
              </Col>
              Welcome to SolSea NFT Marketplace!
            
            </Row>
          </Header>
          <br />
          <Content>
            <br />
            <Card
              style={{
                width: "450px",
                height: "400px",
                display: "flex",
                margin: 0,
                marginLeft: "450px",
                boxShadow: "5px 8px 24px 5px rgba(208, 216, 243, 0.6)",
              }}
            >
              <Title level={3} style={{ marginLeft: "75px" }}>
                Register
              </Title>
              <Divider style={{ marginLeft: "45px" }} />
              <br />
              <Form
                name="basic"
                labelCol={{
                  span: 8,
                }}
                wrapperCol={{
                  span: 16,
                }}
                initialValues={{
                  remember: true,
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
              >
                <Form.Item
                  label="Username"
                  name="username"
                  rules={[
                    {
                      required: true,
                      message: "Please input your username!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>

                <Form.Item
                  label="Password"
                  name="password"
                  rules={[
                    {
                      required: true,
                      message: "Please input your password!",
                    },
                  ]}
                >
                  <Input.Password />
                </Form.Item>
                
                <Row>
                  <Col span={6}>
                    {" "}
                    <Form.Item
                      name="remember"
                      valuePropName="checked"
                      wrapperCol={{ offset: 8 }}
                    >
                      <Checkbox>Remember</Checkbox>
                    </Form.Item>
                  </Col>
                  <Col span={6}>
                    <Button
                      type="primary"
                      style={{ marginLeft: "150px", marginTop: "-10px" }}
                      htmlType="submit"
                      onClick={handleRegister}
                    >
                      Register
                    </Button>
                  </Col>
                </Row>
                <Title level={5} style={{ marginLeft: "100px" }}>
                  Already have an account? <a href="/login">Login</a>
                </Title>
              </Form>
            </Card>
          </Content>
          <Footer
            style={{
              position: "sticky",
              bottom: 0,
            }}
          >
            © 2022 All rights reserved by Chetu India Pvt Ltd.
          </Footer>
        </Layout>
      </Col>
    </>
  );
};

export default Register;
