import { BrowserRouter, Route, Routes } from "react-router-dom";
import WalletContextProvider from "./contexts/WalletContextProvider";
import AppLayout from "./layout/AppLayout";
import "@solana/wallet-adapter-react-ui/styles.css";
import "./App.css";
import Login from "./component/Login";
import Register from "./component/Register";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <WalletContextProvider>
         <Routes>
           <Route path="/" element={<Register/>} />
           <Route path="/login" element={<Login/>} />
           <Route path="/mint" element={<AppLayout/>}></Route>
         </Routes>
        </WalletContextProvider>
      </div>
    </BrowserRouter>
  );
}

export default App;
